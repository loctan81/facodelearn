﻿create database [Movie_Collection]
go
use [Movie_Collection]

go
--Q1:Create your tables
create table Movie(
	Mid int identity(1,1) primary key,
	Name nvarchar(100) not null,
	Duration int not null check(duration >= 60),
	Genre tinyint not null check(genre between 1 and 8),
	Director nvarchar(50),
	MoneyAtBoxOffice decimal(18,2),
	Comments nvarchar(500)
)

create table Actor(
	Aid int identity(1,1) primary key,
	Name nvarchar(50) not null,
	Age tinyint not null,
	Salary decimal(18,2) not null,
	Nationality nvarchar(50) not null
)

create table Actedln(
	Mid int foreign key references Movie(Mid) not null,
	Aid int foreign key references Actor(Aid) not null,
	primary key(Mid,Aid)
)

go
--Q2:Populate tables
alter table Movie
	add ImageLink varchar(100) not null unique

insert into Movie values(N'Mắt Biếc',120,1,N'Victor Vũ',7000000000,N'Qúa hay','https://hinh1/anh.jpg')
insert into Movie values(N'Tiệc Trăng Máu',120,1,N'Nguyễn Quang Dũng',6000000000,N'Phim vui quá mà','https://hinh2/anh1.jpg')
insert into Movie values(N'Cô Dâu Đại Chiến',120,1,N'Thanh Tâm',8000000000,N'Phim hay á','https://hinh3/anh2.jpg')
insert into Movie values(N'Bố Già',120,1,N'Trấn Thành',13000000000,N'Phim cảm động quá','https://hinh4/anh3.jpg')
insert into Movie values(N'Sao Kê',120,1,N'Phương Hằng',23000000000,N'Phim thiếu logic quá','https://hinh5/anh4.jpg')

insert into Actor values(N'Victor Vũ',23,5000000,N'Việt Nam')
insert into Actor values(N'Nguyễn Quang Dũng',32,6000000,N'Việt Nam')
insert into Actor values(N'Thanh Tâm',52,5000000,N'Việt Nam')
insert into Actor values(N'Trấn Thành',22,2000000,N'Việt Nam')
insert into Actor values(N'Phương Hằng',18,1000000,N'Việt Nam')

insert into Actedln values(1,1)
insert into Actedln values(1,2)
insert into Actedln values(2,1)
insert into Actedln values(2,2)
insert into Actedln values(2,3)

update Actor set Name = N'Nguyễn Hoài Lâm' where Aid = 2

go
--Q3:Query tables
select Aid,Name,Age,Salary,Nationality 
from Actor
where Age > 50

select Name, Salary
from Actor
order by Salary

select m.Name as 'Name Movie'
from Actor ac join Actedln a on ac.Aid = a.Aid
				join Movie m on a.Mid = m.Mid
where ac.Name like N'Nguyễn Hoài Lâm'

select Name
from Movie m join Actedln a on m.Mid = a.Mid
where Genre = 1
group by Name
having count(*) > 3
