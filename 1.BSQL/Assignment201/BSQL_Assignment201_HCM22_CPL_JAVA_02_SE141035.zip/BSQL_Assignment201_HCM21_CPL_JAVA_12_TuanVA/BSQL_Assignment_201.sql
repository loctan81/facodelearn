﻿--Create datbase--
create database [Employee Management System]
go

use [Employee Management System]
go
--Q1:
--Create an EMPLOYEE table with the most appropriate/economic field/column constraints & types. All fields are mandatory except Note field.
--Create a SKILL table with the most appropriate/economic field/column constraints & types, all fields are mandatory except Note field.
--Create a DEPARTMENT table with the most appropriate/economic field/column constraints & types, all fields are mandatory except Note field.
--Create EMP_SKILL table with the most appropriate/economic field/column constraints & types, all fields are mandatory except Description field.

create table EMPLOYEE(
	EmpNo int primary key,
	EmpName nvarchar(20) not null,
	BirthDay date not null,
	DeptNo int not null, 
	MgrNo int not null,
	StartDate date not null,
	Salary money not null,
	Level tinyint not null check(Level between 1 and 7),
	Status tinyint not null check(Status between 0 and 2),
	Note nvarchar(max)
)
create table SKILL(
	SkillNo int identity(1,1) primary key,
	SkillName varchar(30) not null,
	Note nvarchar(max)
)

create table DEPARTMENT(
	DeptNo int identity(1,1) primary key,
	DeptName varchar(50) not null,
	Note nvarchar(max)
)

create table EMP_SKILL(
	SkillNo int foreign key references SKILL(SkillNo) not null,
	EmpNo int foreign key references EMPLOYEE(EmpNo) not null,
	SkillLevel tinyint not null,
	check( SkillLevel in(1,2,3)),
	RegDate date not null,
	Description nvarchar(max) not null,
	primary key(SkillNo, SkillLevel)
)
--Q2:
--Add an Email field to EMPLOYEE table and make sure that the database will not allow the value for Email to be inserted into a new row if that value has already been used in another row.
--Modify EMPLOYEE table to set default values to 0 of MgrNo and Status fields.
go

alter table EMPLOYEE 
	add Email varchar(50) not null unique

alter table EMPLOYEE
	add constraint df_MgrNo default 0 for MgrNo

alter table EMPLOYEE
	add constraint df_Status default 0 for Status

--Q3:
--Add the FOREIGN KEY constrain of DeptNo field to the EMPLOYEE table that will relate the DEPARTMENT table.
--Remove the Description field from the EMP_SKILL table

alter table EMPLOYEE
	add constraint FK_DeptNo_DEPARTMENT foreign key (DeptNo) references DEPARTMENT(DeptNo)
alter table EMP_SKILL
	drop column Description

--Q4:
--Add at least 5 records into each of the created tables.
--Create a VIEW called EMPLOYEE_TRACKING that will appear to the user as EmpNo, Emp_Name and Level. It has Level satisfied the criteria: Level >=3 and Level <= 5.
go


insert into DEPARTMENT(DeptName) values('Deparment 101')
insert into DEPARTMENT(DeptName) values('Deparment 102')
insert into DEPARTMENT(DeptName) values('Deparment 103')
insert into DEPARTMENT(DeptName) values('Deparment 104')
insert into DEPARTMENT(DeptName) values('Deparment 105')
go

insert into SKILL(SkillName) values('Tester')
insert into SKILL(SkillName) values('. NET')
insert into SKILL(SkillName) values('JAVA')
insert into SKILL(SkillName) values('BA')
insert into SKILL(SkillName) values('JAVASCRIPT')
go
insert into EMPLOYEE(EmpNo,EmpName,BirthDay,DeptNo,MgrNo,StartDate,Salary,Level,Status,Email) values(1,'Vũ Anh Tuấn','2000-02-13',1,1,'2021-09-16',3300000,5,0,'tuanvase140819@fpt.edu.vn')
insert into EMPLOYEE(EmpNo,EmpName,BirthDay,DeptNo,MgrNo,StartDate,Salary,Level,Status,Email) values(2,'Hồ Quốc Khải','2000-03-11',1,1,'2021-09-16',3300000,4,0,'KhaiHQse140822@fpt.edu.vn')
insert into EMPLOYEE(EmpNo,EmpName,BirthDay,DeptNo,MgrNo,StartDate,Salary,Level,Status,Email) values(3,'Nguyễn Lâm Thanh Tú','2000-01-01',1,1,'2021-09-16',3300000,3,0,'TuNLTTse1403933@fpt.edu.vn')
insert into EMPLOYEE(EmpNo,EmpName,BirthDay,DeptNo,MgrNo,StartDate,Salary,Level,Status,Email) values(4,'Phạm càn Long','1999-12-11',1,1,'2021-09-16',3300000,2,0,'LongPCse140595@fpt.edu.vn')
insert into EMPLOYEE(EmpNo,EmpName,BirthDay,DeptNo,MgrNo,StartDate,Salary,Level,Status,Email) values(5,'Phạm Thành Công','2000-05-11',1,5,'2021-09-16',33000000,7,0,'Conptse12222@fpt.edu.vn')
go
insert into EMP_SKILL(SkillNo,EmpNo,SkillLevel,RegDate) values(1,1,3,'2021-05-1')
insert into EMP_SKILL(SkillNo,EmpNo,SkillLevel,RegDate) values(4,1,3,'2021-05-1')
insert into EMP_SKILL(SkillNo,EmpNo,SkillLevel,RegDate) values(1,2,3,'2021-05-1')
insert into EMP_SKILL(SkillNo,EmpNo,SkillLevel,RegDate) values(1,3,3,'2021-05-1')
insert into EMP_SKILL(SkillNo,EmpNo,SkillLevel,RegDate) values(1,4,3,'2021-05-1')
go
create view EMPLOYEE_TRACKING 
as select EmpNo,EmpName,Level
	from EMPLOYEE 
	where Level >= 3 and Level <= 5
